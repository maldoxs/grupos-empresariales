#
# Copyright (C) 2013 - 2022, Oracle and/or its affiliates. All rights reserved.
# ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
#
from jnius import autoclass
from opg4py._utils.error_handling import java_handler
from ._pgql_statement import PgqlStatement
from ._pgql_prepared_statement import PgqlPreparedStatement

PgqlConnectionClass = autoclass('oracle.pg.rdbms.pgql.PgqlConnection')


class PgqlConnection:
    """Wrapper class for oracle.pg.rdbms.pgql.PgqlConnection."""

    def __init__(self, java_pgql_connection):
        self._java_pgql_connection = java_pgql_connection

    def create_statement(self):
        """Creates a new PgqlStatement object, which is used to execute PGQL queries.

        :return: a new PgqlStatement object that can be used to perform PGQL queries
        """
        java_pgql_statement = java_handler(self._java_pgql_connection.createStatement, [])
        return PgqlStatement(java_pgql_statement)

    @staticmethod
    def get_connection(java_sql_connection):
        """Factory method to get PgqlConnection instance.

        :param java_sql_connection: a JDBC connection
        :return: a PgqlConnection instance
        """
        java_pgql_connection = java_handler(PgqlConnectionClass.getConnection, [java_sql_connection])
        return PgqlConnection(java_pgql_connection)

    def get_graph(self):
        """Get the graph name on which PGQL queries will be executed for this connection.

        :return: the graph name for this connection
        """
        return java_handler(self._java_pgql_connection.getGraph, [])

    def get_jdbc_connection(self):
        """Get the JDBC connection that is used to execute PGQL queries.

        :return: the connection
        """
        return java_handler(self._java_pgql_connection.getJdbcConnection, [])

    def get_schema(self):
        """Get the schema name that will be used to execute PGQL queries with this connection.

        If the schema has not been set, the schema from JDBC connection is returned.

        :return: the schema set for this connection

        Throws:
            PgqlToSqlException - if a database access error occurs or this method is called on a closed connection
        """
        return java_handler(self._java_pgql_connection.getSchema, [])

    def prepare_statement(self, pgql):
        """Creates a new PgqlPreparedStatement object, which represents a pre-compiled PGQL statement.

        :param pgql: the PGQL query to compile
        :return: a PgqlPreparedStatement object that can be used to efficiently execute the same query multiple times
        """
        java_pgql_prepared_statement = java_handler(self._java_pgql_connection.prepareStatement, [pgql])
        return PgqlPreparedStatement(java_pgql_prepared_statement)

    def set_graph(self, graph):
        """Sets the graph name on which PGQL queries will be executed for this connection.

        :param graph: the name of the graph
        """
        java_handler(self._java_pgql_connection.setGraph, [graph])

    def set_schema(self, schema):
        """Sets the schema name that will be used to execute PGQL queries with this connection.

        :param schema: the name of the schema
        """
        java_handler(self._java_pgql_connection.setSchema, [schema])

    def close(self):
        """Free the resources of the internal JDBC connection."""
        java_handler(self._java_pgql_connection.conn.close, [])

    def __repr__(self):
        return "{}(schema: {}, graph: {})".format(self.__class__.__name__, self.get_schema(), self.get_graph())

    def __str__(self):
        return repr(self)
