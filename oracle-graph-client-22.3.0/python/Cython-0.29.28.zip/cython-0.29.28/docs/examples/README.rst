This example directory is organized like the ``Cython/docs/src/`` directory,
with one directory per ``.rst`` file. All files in this directory are tested
in the :file:`runtests.py` with the mode `compile`.
