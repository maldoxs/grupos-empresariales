double sinc(double);
